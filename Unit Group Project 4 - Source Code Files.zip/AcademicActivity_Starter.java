/*
 Part 4 (Starter) — AcademicActivity_Starter
*/

public class AcademicActivity_Starter extends BaseActivity_Starter implements Prioritizable_Starter {

    // TODO 1: Add field: private int credits;
    private int credits;

    // TODO 2: Constructor: (String name, double weeklyHours, int credits)
    // - call super(name, weeklyHours)
    // - set credits

    public AcademicActivity_Starter(String name, double weeklyHours, int credits) {
        super(name, weeklyHours);
        this.credits = credits;
    }
    // TODO 3: Implement getDescription()
    // Example: "Academic: <name> | Hours: <weeklyHours> | Credits: <credits>"

    @Override
    public String getDescription() {
        return "Name: " + name + "\nWeekly Hours: " + weeklyHours + "\nCredits: " + credits;
    }

    // TODO 4: Implement getPriorityScore()
    // Example: weeklyHours * credits

    @Override
    public double getPriorityScore() {
        return weeklyHours * credits;
    }

}
