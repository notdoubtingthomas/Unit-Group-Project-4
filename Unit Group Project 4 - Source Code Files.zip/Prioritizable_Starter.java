/*
 Part 4 (Starter) — Prioritizable_Starter (interface)
*/

public interface Prioritizable_Starter {
    // TODO: declare double getPriorityScore();
    public double getPriorityScore();
}
