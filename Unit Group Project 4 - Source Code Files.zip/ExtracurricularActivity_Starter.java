/*
 Part 4 (Starter) — ExtracurricularActivity_Starter
*/

public class ExtracurricularActivity_Starter extends BaseActivity_Starter implements Prioritizable_Starter {

    // TODO 1: Add field: private String location;

    private String location;

    // TODO 2: Constructor: (String name, double weeklyHours, String location)
    // - call super(name, weeklyHours)
    // - set location

    public ExtracurricularActivity_Starter(String name, double weeklyHours, String location) {
        super(name, weeklyHours);
        this.location = location;
    }

    // TODO 3: Implement getDescription()
    // Example: "Extracurricular: <name> | Hours: <weeklyHours> | Location: <location>"

    @Override
    public String getDescription() {
        return "Extracurricular: " + name + "\nWeekly Hours: " + weeklyHours + "\nLocation: " + location;
    }
    // TODO 4: Implement getPriorityScore()
    // Example: weeklyHours * 1.5

    @Override
    public double getPriorityScore() {
        return weeklyHours * 1.5;
    }

}
