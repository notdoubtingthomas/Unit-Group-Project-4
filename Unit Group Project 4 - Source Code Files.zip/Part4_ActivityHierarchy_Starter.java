/*
 Part 4 (Starter) — Activity Hierarchy Driver
*/

public class Part4_ActivityHierarchy_Starter {

    public static void main(String[] args) {

        // TODO 1: Create at least 3 activity objects (mix of academic/extracurricular)

        AcademicActivity_Starter mathFair = new AcademicActivity_Starter("Math Fair", 20.0, 4);
        AcademicActivity_Starter spellingBee = new AcademicActivity_Starter("Spelling Bee", 25.0, 3);
        ExtracurricularActivity_Starter football = new ExtracurricularActivity_Starter("Football", 35.0, "Football Field");

        // TODO 2: Store them in an array of BaseActivity_Starter:
        // BaseActivity_Starter[] activities = { ... };

        BaseActivity_Starter[] activities = {mathFair, spellingBee, football};

        // TODO 3: Loop through the array to:
        // - print getDescription()
        // - sum total weekly hours
        // - sum total priority score

        double totalWeeklyHours = 0.0;
        double totalPriorityScore = 0.0;

        System.out.println("=== ACTIVITIES SUMMARY ===");

        for (BaseActivity_Starter activity : activities) {
            String description = activity.getDescription();
            System.out.println(description);
            System.out.println("===============");
            totalWeeklyHours += activity.getWeeklyHours();
            totalPriorityScore += activity.getPriorityScore();
        }

        // TODO 4: Print summary totals (hours and priority)

        System.out.println("=== SUMMARY ===");
        System.out.println("Total Weekly Hours: " + totalWeeklyHours);
        System.out.println("Total Priority Score: " + totalPriorityScore);
        System.out.println("===============");
    }
}
