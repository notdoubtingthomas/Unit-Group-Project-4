/*
 Part 4 (Starter) — BaseActivity_Starter (abstract base class)
 Modules 8–10: Arrays, Inheritance, Interfaces, Polymorphism

 Teaching Cues:
 - Use an abstract base class to capture shared fields/behavior
 - Require subclasses to implement key methods via abstract methods
*/

public abstract class BaseActivity_Starter {

    // TODO 1: Declare protected fields:
    // protected String name;
    // protected double weeklyHours;

    protected String name;
    protected double weeklyHours;

    // TODO 2: Implement constructor with both fields

    public BaseActivity_Starter(String name, double weeklyHours) {
        this.name = name;
        this.weeklyHours = weeklyHours;
    }

    // TODO 3: Create getters and setters

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getWeeklyHours() {
        return weeklyHours;
    }

    public void setWeeklyHours(double weeklyHours) {
        this.weeklyHours = weeklyHours;
    }

    // TODO 4: Declare abstract method:
    // public abstract String getDescription();

    public abstract String getDescription();

    // TODO 5: Declare abstract method:
    // public abstract double getPriorityScore();

    public abstract double getPriorityScore();

}
